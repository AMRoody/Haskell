# 0.4.0

- Add 'haskell-scry' to package list.

# 0.3.0

- Setup default configuration for the user.

# 0.1.0 - First Release

- Every feature added.
- Every bug fixed.
